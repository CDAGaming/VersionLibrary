-- itIT localization
local L = LibStub("AceLocale-3.0"):NewLocale("WOWUP", "itIT")
if not L then return end

L["Notification"] = "Notifica"
L["You have 1 addon to be updated"] = "Hai 1 addon da aggiornare"
L["You have %d addons to be updated"] = "Hai %d addons da aggiornare"
L["All addons are up-to-date"] = "Tutti gli addons sono aggiornati"
L["Show a popup with a notification after loading when updates are available"] = "Mostra un popup di notifica quando sono disponibili degli aggiornamenti (dopo il Login)"
L["Show a chat message indicating whether or not updates are available"] = "Mostra un messaggio in chat se sono disponibili o meno degli aggiornamenti (dopo il Login)"
L["Click to open settings"] = true
L["Show a list of all addons to be updated in a popup notification"] = true
L["Show a list of all addons to be updated in a chat message"] = true
L["Show Minimap icon"] = true
