-- enUS localization
local L = LibStub("AceLocale-3.0"):NewLocale("WOWUP", "enUS", true, true)

L["Notification"] = true
L["You have 1 addon to be updated"] = true
L["You have %d addons to be updated"] = true
L["All addons are up-to-date"] = true
L["Show a popup with a notification after loading when updates are available"] = true
L["Show a chat message indicating whether or not updates are available"] = true
L["Click to open settings"] = true
L["Show a list of all addons to be updated in a popup notification"] = true
L["Show a list of all addons to be updated in a chat message"] = true
L["Show Minimap icon"] = true