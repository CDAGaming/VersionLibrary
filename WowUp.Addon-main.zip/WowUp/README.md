**WARNING: This addon is still in early development**

# Addon Update Notifications (by WowUp)
_The official WowUp World of Warcraft addon_

This addon receives data from an addon manager like WowUp and enables an in-game
notification when you first load, or reload the interface. This addon won't run
without an addon manager that supports this feature. Managers that are known to
support this:
  - [WowUp application](https://wowup.io/)

